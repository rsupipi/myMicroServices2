package com.pipi.myMicroServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMicroServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
