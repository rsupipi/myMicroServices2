package com.pipi.netflixzuulapigatewaysrever;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetflixZuulApiGatewaySreverApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetflixZuulApiGatewaySreverApplication.class, args);
	}

}
